export default function Disponibilidade() {
    return <h1>Buscar Lar</h1>;
  }
  