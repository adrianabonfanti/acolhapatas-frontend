export default function MeusDadosLar() {
    return <h1>Buscar Lar</h1>;
  }
  