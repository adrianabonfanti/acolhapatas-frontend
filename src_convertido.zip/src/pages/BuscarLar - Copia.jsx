export default function BuscarLar() {
    return <h1>Buscar Lar</h1>;
  }
  